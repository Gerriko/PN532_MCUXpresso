/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * Application Copyright 2019 BigG (gerrikoio)
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef PROJECT2BOARDMAPPINGS_H_
#define PROJECT2BOARDMAPPINGS_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define PN532_IRQ_GPIO						BOARD_INITPINS_PIN_IRQ_GPIO //-- see pin_mux.h
#define PN532_IRQ_PORT						BOARD_INITPINS_PIN_IRQ_PORT //-- see pin_mux.h
#define PN532_IRQ_PIN						BOARD_INITPINS_PIN_IRQ_PIN //-- see pin_mux.h

#define PN532_VEN_GPIO						BOARD_INITPINS_PIN_VEN_GPIO //-- see pin_mux.h
#define PN532_VEN_PORT						BOARD_INITPINS_PIN_VEN_PORT //-- see pin_mux.h
#define PN532_VEN_PIN						BOARD_INITPINS_PIN_VEN_PIN //-- see pin_mux.h

#define BOARD_LED_GPIO 						BOARD_LED_RED_GPIO
#define BOARD_LED_GPIO_PIN 					BOARD_LED_RED_GPIO_PIN

#define HOST_I2C_MASTER_BASEADDR 			I2C1
#define HOST_I2C_CLK_SRC 					I2C1_CLK_SRC
#define HOST_I2C_CLK_FREQ 					CLOCK_GetFreq(I2C1_CLK_SRC)

#define I2C_BAUDRATE 						100000U



#endif /* PROJECT2BOARDMAPPINGS_H_ */
