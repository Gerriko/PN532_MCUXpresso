/**************************************************************************/
/*!
 * Copyrights:
    @Original   	Adafruit_PN532.h
    @author   		Adafruit Industries
    @license  		BSD (see license.txt)

    @NewFile		PN532.h
 	@created on:	18 Apr 2019
    @author			BigG/gerrikoio
    @license  		BSD (see license.txt)

	This C Library has been modified to work with NXP devices such as FRDM-KW41Z
	This C Library has only implemented I2C
	Many functions in this library have been adapted to use fsl drivers
	Some functions have been modified to make debugging easier

	Purpose of library is to provide a driver for NXP's PN532
	NFC/13.56MHz RFID Transceiver
	These chips use SPI or I2C to communicate.

	This is a library for the Adafruit PN532 NFC/RFID breakout boards
	This library works with the Adafruit NFC breakout
	----> https://www.adafruit.com/products/364

	Check out the links above for our tutorials and wiring diagrams

	Adafruit invests time and resources providing this open source code,
	please support Adafruit and open-source hardware by purchasing
	products from Adafruit!

*/
/**************************************************************************/


#ifndef PN532_H_
#define PN532_H_

#define PN532_SLAVE_ADDRESS					0x48U >> 1

#define PN532_PREAMBLE                      0x00U
#define PN532_STARTCODE1                    0x00U
#define PN532_STARTCODE2                    0xFFU
#define PN532_POSTAMBLE                     0x00U

#define PN532_HOSTTOPN532                   0xD4U
#define PN532_PN532TOHOST                   0xD5U

#define PN532_I2C_READY                     0x01U

#define PN532_COMMAND_DIAGNOSE              0x00U
#define PN532_COMMAND_GETFIRMWAREVERSION    0x02U
#define PN532_COMMAND_GETGENERALSTATUS      0x04U
#define PN532_COMMAND_READREGISTER          0x06U
#define PN532_COMMAND_WRITEREGISTER         0x08U
#define PN532_COMMAND_READGPIO              0x0CU
#define PN532_COMMAND_WRITEGPIO             0x0EU
#define PN532_COMMAND_SETSERIALBAUDRATE     0x10U
#define PN532_COMMAND_SETPARAMETERS         0x12U
#define PN532_COMMAND_SAMCONFIGURATION      0x14U
#define PN532_COMMAND_POWERDOWN             0x16U
#define PN532_COMMAND_RFCONFIGURATION       0x32U
#define PN532_COMMAND_RFREGULATIONTEST      0x58U
#define PN532_COMMAND_INJUMPFORDEP          0x56U
#define PN532_COMMAND_INJUMPFORPSL          0x46U
#define PN532_COMMAND_INLISTPASSIVETARGET   0x4AU
#define PN532_COMMAND_INATR                 0x50U
#define PN532_COMMAND_INPSL                 0x4EU
#define PN532_COMMAND_INDATAEXCHANGE        0x40U
#define PN532_COMMAND_INCOMMUNICATETHRU     0x42U
#define PN532_COMMAND_INDESELECT            0x44U
#define PN532_COMMAND_INRELEASE             0x52U
#define PN532_COMMAND_INSELECT              0x54U
#define PN532_COMMAND_INAUTOPOLL            0x60U
#define PN532_COMMAND_TGINITASTARGET        0x8CU
#define PN532_COMMAND_TGSETGENERALBYTES     0x92U
#define PN532_COMMAND_TGGETDATA             0x86U
#define PN532_COMMAND_TGSETDATA             0x8EU
#define PN532_COMMAND_TGSETMETADATA         0x94U
#define PN532_COMMAND_TGGETINITIATORCOMMAND 0x88U
#define PN532_COMMAND_TGRESPONSETOINITIATOR 0x90U
#define PN532_COMMAND_TGGETTARGETSTATUS     0x8AU

#define PN532_RESPONSE_INDATAEXCHANGE       0x41U
#define PN532_RESPONSE_INLISTPASSIVETARGET  0x4BU

#define PN532_WAKEUP                        0x55U

#define PN532_MIFARE_ISO14443A              0x00U

// Mifare Commands
#define MIFARE_CMD_AUTH_A                   0x60U
#define MIFARE_CMD_AUTH_B                   0x61U
#define MIFARE_CMD_READ                     0x30U
#define MIFARE_CMD_WRITE                    0xA0U
#define MIFARE_CMD_TRANSFER                 0xB0U
#define MIFARE_CMD_DECREMENT                0xC0U
#define MIFARE_CMD_INCREMENT                0xC1U
#define MIFARE_CMD_STORE                    0xC2U
#define MIFARE_ULTRALIGHT_CMD_WRITE         0xA2U

// Prefixes for NDEF Records (to identify record type)
#define NDEF_URIPREFIX_NONE                 0x00U
#define NDEF_URIPREFIX_HTTP_WWWDOT          0x01U
#define NDEF_URIPREFIX_HTTPS_WWWDOT         0x02U
#define NDEF_URIPREFIX_HTTP                 0x03U
#define NDEF_URIPREFIX_HTTPS                0x04U
#define NDEF_URIPREFIX_TEL                  0x05U
#define NDEF_URIPREFIX_MAILTO               0x06U
#define NDEF_URIPREFIX_FTP_ANONAT           0x07U
#define NDEF_URIPREFIX_FTP_FTPDOT           0x08U
#define NDEF_URIPREFIX_FTPS                 0x09U
#define NDEF_URIPREFIX_SFTP                 0x0AU
#define NDEF_URIPREFIX_SMB                  0x0BU
#define NDEF_URIPREFIX_NFS                  0x0CU
#define NDEF_URIPREFIX_FTP                  0x0DU
#define NDEF_URIPREFIX_DAV                  0x0EU
#define NDEF_URIPREFIX_NEWS                 0x0FU
#define NDEF_URIPREFIX_TELNET               0x10U
#define NDEF_URIPREFIX_IMAP                 0x11U
#define NDEF_URIPREFIX_RTSP                 0x12U
#define NDEF_URIPREFIX_URN                  0x13U
#define NDEF_URIPREFIX_POP                  0x14U
#define NDEF_URIPREFIX_SIP                  0x15U
#define NDEF_URIPREFIX_SIPS                 0x16U
#define NDEF_URIPREFIX_TFTP                 0x17U
#define NDEF_URIPREFIX_BTSPP                0x18U
#define NDEF_URIPREFIX_BTL2CAP              0x19U
#define NDEF_URIPREFIX_BTGOEP               0x1AU
#define NDEF_URIPREFIX_TCPOBEX              0x1BU
#define NDEF_URIPREFIX_IRDAOBEX             0x1CU
#define NDEF_URIPREFIX_FILE                 0x1DU
#define NDEF_URIPREFIX_URN_EPC_ID           0x1EU
#define NDEF_URIPREFIX_URN_EPC_TAG          0x1FU
#define NDEF_URIPREFIX_URN_EPC_PAT          0x20U
#define NDEF_URIPREFIX_URN_EPC_RAW          0x21U
#define NDEF_URIPREFIX_URN_EPC              0x22U
#define NDEF_URIPREFIX_URN_NFC              0x23U

#define PN532_GPIO_VALIDATIONBIT            0x80U


#define PN532_PACKBUFFSIZE 					64

/* LOOP_REF and CLOCK_CALL_TIME must be adapted according to the CPU execution time */
#define LOOP_REF							1000
#define CLOCK_CALL_TIME 					100

#define TIMEOUT_INFINITE					0
#define TIMEOUT_100MS						100
#define TIMEOUT_1S							1000
#define TIMEOUT_2S							2000

// Debugging / Runtime options. Comment out if you do not want to see debug info
//#define PN532DEBUG
//#define MIFAREDEBUG
//#define ALLOWWRITETESTS


/*******************************************************************************
 * PN532 Write Functions
 ******************************************************************************/
bool PN532_mifareclassic_WriteDataBlock (uint8_t blockNumber, uint8_t *data);

/*******************************************************************************
 * PN532 Read Functions
 ******************************************************************************/
bool PN532_mifareultralight_ReadPage (uint8_t page, uint8_t *buffer);
bool PN532_ntag2xx_ReadPage (uint8_t page, uint8_t *buffer);
bool PN532_mifareclassic_ReadDataBlock (uint8_t blockNumber, uint8_t * data);
bool PN532_mifareclassic_AuthenticateBlock (uint8_t *uid, uint8_t uidLen, uint32_t blockNumber, uint8_t keyNumber, const uint8_t *keyData);

/*******************************************************************************
 * Generic PN532 functions
 ******************************************************************************/
bool PN532_readPassiveTargetID(uint8_t *uid, uint8_t *uidLength);
bool PN532_initiateCardReader(uint8_t cardbaudrate);
bool PN532_SAMConfig(void);

/*******************************************************************************
 * PN532 Utility functions
 ******************************************************************************/
uint32_t I2C_getPN532FirmwareVersion(void);
void PN532reset(void);
void PN532_PrintHex(const uint8_t* data, const uint32_t numBytes);
void PN532_PrintHexChar(const uint8_t* data, const uint32_t numBytes);
void MCUsleep(uint32_t ms);

#endif /* PN532_H_ */
