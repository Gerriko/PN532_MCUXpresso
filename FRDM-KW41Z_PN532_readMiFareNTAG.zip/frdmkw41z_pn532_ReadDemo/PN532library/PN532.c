/**************************************************************************/
/*!
 * Copyrights:
    @Original   	Adafruit_PN532.cpp
    @author   		Adafruit Industries
    @license  		BSD (see license.txt)

    @NewFile		PN532.c
 	@created on:	18 Apr 2019
    @author			BigG/gerrikoio
    @license  		BSD (see license.txt)

	This C Library has been modified to work with NXP devices such as FRDM-KW41Z
	This C Library has only implemented I2C
	Many functions in this library have been adapted to use fsl drivers
	Some functions have been modified to make debugging easier

	Purpose of library is to provide a driver for NXP's PN532
	NFC/13.56MHz RFID Transceiver
	These chips use SPI or I2C to communicate.

	This is a library for the Adafruit PN532 NFC/RFID breakout boards
	This library works with the Adafruit NFC breakout
	----> https://www.adafruit.com/products/364

	Check out the links above for our tutorials and wiring diagrams

	Adafruit invests time and resources providing this open source code,
	please support Adafruit and open-source hardware by purchasing
	products from Adafruit!

*/
/**************************************************************************/


/*  SDK Included Files */
#include <projectML/project2boardmappings.h>
#include <stdio.h>
#include <time.h>

#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_i2c.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_gpio.h"
#include "fsl_port.h"
#include "fsl_common.h"

#include "PN532.h"

/*******************************************************************************
 * Variables
 ******************************************************************************/

uint8_t pn532response_firmwarevers[] = {0x00, 0xFF, 0x06, 0xFA, 0xD5, 0x03};

uint8_t pn532_packetbuffer[PN532_PACKBUFFSIZE];

extern i2c_master_config_t masterConfig;
extern uint32_t sourceClock;
extern i2c_master_transfer_t masterXfer;

uint8_t AckResponse = 0;


/**************************************************************************/
/****************** ISO14443A Internal Library Functions *******************/
/**************************************************************************/


static void Decode_kStatusOutput(status_t sCode)
{
	switch (sCode) {
		case kStatus_I2C_Busy:
			printf("I2C_Busy\r\n");
			break;
		case kStatus_I2C_Timeout:
			printf("I2C_Timeout\r\n");
			break;
		case kStatus_I2C_ArbitrationLost:
			printf("I2C_ArbitrationLost\r\n");
			break;
		case kStatus_I2C_Nak:
			printf("I2C_Nak\r\n");
			break;
		default:
			printf("unknown %ld\r\n", sCode);
	}
}

static bool writecommand(uint8_t *cmdPacketData, uint8_t lenPackData)
{
	// Communication between host controller and PN532 is performed through frames
	/* Structure of this frame is the following:
	 *	PREAMBLE 1 byte (0x00)
	 *	Start of Packet Code: 2 bytes (0x00 and 0xFF)
	 *	Packet Length (1 byte indicating the number of bytes in the data field = LEN)
	 *	Packet Length Checksum (Packet Length Checksum LCS byte that satisfies the relation: Lower byte of [LEN + LCS] = 0x00)
	 *	Specific PN532 Frame Identifier (0xD4 in case of a frame from the host controller to the PN532)
	 *	Packet Data (LEN-1 bytes of Packet Data Information. The first byte PD0 is the Command Code)
	 *	Packet Data Checksum (Data Checksum DCS byte that satisfies the relation: Lower byte of [TFI + PD0 + PD1 + … + PDn + DCS] = 0x00)
	 *	Postamble (0x00)
	 */

	uint8_t i = 0;
	uint8_t cmdlen = lenPackData+1;
	uint8_t cmdCheckSum = (uint8_t)(~cmdlen + 1);
	// This example assumes data packet (command) is always 1 byte in length
    uint16_t PDchecksum = (PN532_PREAMBLE + PN532_PREAMBLE + PN532_STARTCODE2 + PN532_HOSTTOPN532);  // + cmdPacketData later

	uint8_t FrameData[8 + lenPackData];

	FrameData[0] = PN532_PREAMBLE;
	FrameData[1] = PN532_STARTCODE1;
	FrameData[2] = PN532_STARTCODE2;
	FrameData[3] = cmdlen;
	FrameData[4] = cmdCheckSum;
	FrameData[5] = PN532_HOSTTOPN532;
	// add in the packet data
	for (i = 0; i < lenPackData; i++) {
		FrameData[6+i] = cmdPacketData[i];
		PDchecksum += cmdPacketData[i];
	}
	FrameData[6+lenPackData] = (uint8_t)(~PDchecksum);
	FrameData[6+lenPackData+1] = PN532_POSTAMBLE;

    #ifdef PN532DEBUG
	printf("\r\nSending Command: ");
	for (i = 0; i < 9; i++) {
		printf(" 0x%X", FrameData[i]);
	}
	printf("\r\n");
	#endif

	MCUsleep(2);

    // I2C WRITE COMMAND
    masterXfer.direction = kI2C_Write;
    masterXfer.data = FrameData;
    masterXfer.dataSize = sizeof(FrameData);
    masterXfer.flags = kI2C_TransferDefaultFlag;		// Sends a stop command following data transfer

    status_t I2C_ReadResponse = I2C_MasterTransferBlocking(HOST_I2C_MASTER_BASEADDR, &masterXfer);

    if (I2C_ReadResponse == kStatus_Success) {
      	return true;
    }
    else {
    	// Try again
        I2C_ReadResponse = I2C_MasterTransferBlocking(HOST_I2C_MASTER_BASEADDR, &masterXfer);
        if (I2C_ReadResponse == kStatus_Success) {
          	return true;
        }
        else {
			#ifdef PN532DEBUG
			printf("I2C Write Error: ");
			Decode_kStatusOutput(I2C_ReadResponse);
			#endif
        	return false;
        }
    }
}

static bool readAckData(void)
{
	// This reads 7 bytes of data and checks that the first is RDY=1 and the other 6 match the ack frame

	const uint8_t pn532ackFrame[6] = {0x00, 0x00, 0xFF, 0x00, 0xFF, 0x00};

	uint8_t ackResponse[7] = {0};
	uint8_t i = 0;
	uint8_t j = 0;
	bool ackFrameMatch = true;

	MCUsleep(2);
    // I2C WRITE COMMAND
    masterXfer.direction = kI2C_Read;
    masterXfer.data = ackResponse;
    masterXfer.dataSize = sizeof(ackResponse);
    masterXfer.flags = kI2C_TransferDefaultFlag;		// Sends a stop command following data transfer

    // We set it up to try 3 times to see if we get a RDY response
    for (i = 0; i < 3; i++) {

		status_t I2C_ReadResponse = I2C_MasterTransferBlocking(HOST_I2C_MASTER_BASEADDR, &masterXfer);

		if (I2C_ReadResponse == kStatus_Success) {
			// Now need to check the first byte
			// If RDY = 1 then can read the rest of the data, otherwise we try again
			#ifdef PN532DEBUG
			printf("RDY is 0x%X\r\n", ackResponse[0]);
			#endif
			if (ackResponse[0] == PN532_I2C_READY) {
				// Can now check the rest of the data
				#ifdef PN532DEBUG
				printf("Frame Response is ");
				#endif
				for (j = 1; j < 7; j++) {
					if (ackResponse[j] != pn532ackFrame[j-1]) ackFrameMatch = false;
					#ifdef PN532DEBUG
					printf(" 0x%X", ackResponse[j]);
					#endif
				}
				#ifdef PN532DEBUG
				printf("\r\n");
				#endif
				if (!ackFrameMatch) {
					#ifdef PN532DEBUG
					printf("Frame Response does not match!\r\n");
					#endif
					return false;
				}
			}
			return true;
		}
		else {
			#ifdef PN532DEBUG
			printf("I2C Read Error: ");
			Decode_kStatusOutput(I2C_ReadResponse);
			#endif
			return false;
		}
		MCUsleep(2);
    }
    return false;
}

static bool readDataPacket(uint8_t* buff, uint8_t n)
{
	// This reads the specified number of bytes of data and checks that the first is RDY=1 and the other 6 match the ack frame

	uint8_t i = 0;
	uint8_t j = 0;
	uint8_t tempBuff[n+1];
	bool ackFrameMatch = true;

	MCUsleep(10);
    // I2C WRITE COMMAND
    masterXfer.direction = kI2C_Read;
    masterXfer.data = tempBuff;
    masterXfer.dataSize = sizeof(tempBuff);
    masterXfer.flags = kI2C_TransferDefaultFlag;		// Sends a stop command following data transfer

    // We set it up to try 3 times to see if we get a RDY response
    for (i = 0; i < 3; i++) {

		status_t I2C_ReadResponse = I2C_MasterTransferBlocking(HOST_I2C_MASTER_BASEADDR, &masterXfer);

		if (I2C_ReadResponse == kStatus_Success) {
			// Now need to check the first byte
			// If RDY = 1 then can read the rest of the data, otherwise we try again
			#ifdef PN532DEBUG
			printf("RDY is 0x%X\r\n", tempBuff[0]);
			#endif
			if (tempBuff[0] == PN532_I2C_READY) {
				// Can now check the rest of the data

				memcpy (buff, tempBuff+1, n);

				#ifdef PN532DEBUG
				printf("Data Received is ");
				for (j = 0; j < n; j++) {
					printf(" 0x%X", buff[j]);
				}
				printf("\r\n");
				#endif

				if (!ackFrameMatch) {
					#ifdef PN532DEBUG
					printf("Frame Response does not match!\r\n");
					#endif
					return false;
				}
				return true;
			}
		}
		else {
			#ifdef PN532DEBUG
			printf("I2C Read Error: ");
			Decode_kStatusOutput(I2C_ReadResponse);
			#endif
			return false;
		}
		MCUsleep(2);
    }
    return false;
}

static bool checkIRQpinIfReady()
{
	// Now can check for acknowledgment and then read the data
	uint32_t to = TIMEOUT_1S;
	uint32_t PinState = 0;

	while ((PinState = GPIO_ReadPinInput(PN532_IRQ_GPIO, PN532_IRQ_PIN)) == 1) {
		MCUsleep(10);
		to -= 10;
		if (to <= 0) break;
	}
	if (to <= 0) {
		#ifdef PN532DEBUG
		printf("IRQ TIMEOUT!\r\n");
		#endif
		return false;
	}
	else {
		#ifdef PN532DEBUG
		printf("%ld - IRQ Response!\r\n", to);
		#endif
		return true;
	}
}

static uint8_t sendCommandCheckAck(uint8_t *cmd, uint8_t cmdlen, uint16_t timeout)
{
	if (writecommand(cmd, cmdlen)) {
		// check IRQ pin response
		if (checkIRQpinIfReady()) {					// TODO --- add in the timeout
			// check ack - also uses frames
			if (readAckData()) {
				return 1;			// 1 = All Good
			}
			else return 2;			// 2 = Error - Failed to read Ack Data
		}
		else return 3;				// 3 = Error - Failed to receive IRQ pin state change within timeout
	}
	else return 4;					// 4 = Error - Failed to write command
}



/**************************************************************************/
/****************** ISO14443A Visible Library Functions *******************/
/**************************************************************************/

/***** A Mifare Ultralight Function ******/
/**************************************************************************/
/*!
    Tries to read an entire 4-byte page at the specified address.

    @param  page        The page number (0..63 in most cases)
    @param  buffer      Pointer to the byte array that will hold the
                        retrieved data (if any)
*/
/**************************************************************************/

bool PN532_mifareultralight_ReadPage (uint8_t page, uint8_t *buffer)
{
	if (page >= 64) {
		#ifdef MIFAREDEBUG
			printf("Page value out of range for Mifare Ultralight\r\n");
		#endif
		return 0;
	}

	#ifdef MIFAREDEBUG
		printf("Reading page %d:", page);
	#endif

	/* Prepare the command */
	pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;
	pn532_packetbuffer[1] = 1;                   /* Card number */
	pn532_packetbuffer[2] = MIFARE_CMD_READ;     /* Mifare Read command = 0x30 */
	pn532_packetbuffer[3] = page;                /* Page Number (0..63 in most cases) */

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 4, TIMEOUT_1S);

	if (AckResponse == 1) {
		/* Read the response packet */
		memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
		// read data packet to see ok
		readDataPacket(pn532_packetbuffer, 26);
		#ifdef MIFAREDEBUG
			printf("Received: ");
			PN532_PrintHexChar(pn532_packetbuffer, 26);
		#endif

		/* If byte 8 isn't 0x00 we probably have an error */
		if (pn532_packetbuffer[7] == 0x00) {
			/* Copy the 4 data bytes to the output buffer         */
			/* Block content starts at byte 9 of a valid response */
			/* Note that the command actually reads 16 byte or 4  */
			/* pages at a time ... we simply discard the last 12  */
			/* bytes                                              */
			memcpy (buffer, pn532_packetbuffer+8, 4);
		}
		else {
			#ifdef MIFAREDEBUG
				printf("Unexpected response reading block: \r\n");
				PN532_PrintHexChar(pn532_packetbuffer, 26);
			#endif
			return 0;
		}

		/* Display data for debug if requested */
		#ifdef MIFAREDEBUG
			printf("Page %d:", page);
			PN532_PrintHexChar(buffer, 4);
		#endif

		// Return OK signal
		return 1;

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - PN532_mifareultralight_ReadPage: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - PN532_mifareultralight_ReadPage: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - PN532_mifareultralight_ReadPage: Failed to write command\r\n");
			break;
		}
		#endif
	}

	return 0;

}

/**************************************************************************/
/*!
    Tries to read an entire 4-byte page at the specified address.

    @param  page        The page number (0..63 in most cases)
    @param  buffer      Pointer to the byte array that will hold the
                        retrieved data (if any)
*/
/**************************************************************************/

bool PN532_ntag2xx_ReadPage (uint8_t page, uint8_t *buffer)
{
	// TAG Type       PAGES   USER START    USER STOP
	// --------       -----   ----------    ---------
	// NTAG 203       42      4             39
	// NTAG 213       45      4             39
	// NTAG 215       135     4             129
	// NTAG 216       231     4             225

	if (page >= 231) {
		#ifdef MIFAREDEBUG
			printf("Page value out of range\r\n");
		#endif
		return 0;
	}

	#ifdef MIFAREDEBUG
		printf("Reading page %d\r\n", page);
	#endif

	/* Prepare the command */
	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
	pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;
	pn532_packetbuffer[1] = 1;                   /* Card number */
	pn532_packetbuffer[2] = MIFARE_CMD_READ;     /* Mifare Read command = 0x30 */
	pn532_packetbuffer[3] = page;                /* Page Number (0..63 in most cases) */

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 4, TIMEOUT_1S);

	if (AckResponse == 1) {
		/* Read the response packet */
		memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
		// read data packet to see ok
		readDataPacket(pn532_packetbuffer, 26);
		#ifdef MIFAREDEBUG
			printf("Received: \r\n");
			PN532_PrintHexChar(pn532_packetbuffer, 26);
		#endif

		/* If byte 8 isn't 0x00 we probably have an error */
		if (pn532_packetbuffer[7] == 0x00) {
			/* Copy the 4 data bytes to the output buffer         */
			/* Block content starts at byte 9 of a valid response */
			/* Note that the command actually reads 16 byte or 4  */
			/* pages at a time ... we simply discard the last 12  */
			/* bytes                                              */
			memcpy (buffer, pn532_packetbuffer+8, 4);
		}
		else {
			#ifdef MIFAREDEBUG
				printf("Unexpected response reading block: \r\n");
				PN532_PrintHexChar(pn532_packetbuffer, 26);
			#endif
			return 0;
		}

		/* Display data for debug if requested */
		#ifdef MIFAREDEBUG
			printf("Page %d:\r\n", page);
			PN532_PrintHexChar(buffer, 4);
		#endif

		// Return OK signal
		return 1;

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - PN532_ntag2xx_ReadPage: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - PN532_ntag2xx_ReadPage: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - PN532_ntag2xx_ReadPage: Failed to write command\r\n");
			break;
		}
		#endif
	}

	return 0;

}
/**************************************************************************/
/*!
    Tries to read an entire 16-byte data block at the specified block
    address.

    @param  blockNumber   The block number to authenticate.  (0..63 for
                          1KB cards, and 0..255 for 4KB cards).
    @param  data          Pointer to the byte array that will hold the
                          retrieved data (if any)

    @returns 1 if everything executed properly, 0 for an error
*/
/**************************************************************************/

bool PN532_mifareclassic_ReadDataBlock (uint8_t blockNumber, uint8_t * data)
{
	#ifdef MIFAREDEBUG
		printf("Trying to read 16 bytes from block %d\r\n", blockNumber);
	#endif

	/* Prepare the first command */
	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
	pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;
	pn532_packetbuffer[1] = 1;                      /* Card number */
	pn532_packetbuffer[2] = MIFARE_CMD_READ;        /* Mifare Read command = 0x30 */
	pn532_packetbuffer[3] = blockNumber;            /* Block Number (0..63 for 1K, 0..255 for 4K) */

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 4, TIMEOUT_1S);

	if (AckResponse == 1) {

		/* Read the response packet */
		//memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
		// read data packet to see ok
		readDataPacket(pn532_packetbuffer, 26);

		/* If byte 8 isn't 0x00 we probably have an error */
		if (pn532_packetbuffer[7] != 0x00)
		{
		#ifdef MIFAREDEBUG
		  printf("Unexpected response reading block: ");
		  PN532_PrintHexChar(pn532_packetbuffer, 26);
		#endif
		return 0;
		}

		/* Copy the 16 data bytes to the output buffer        */
		/* Block content starts at byte 9 of a valid response */
		memcpy (data, pn532_packetbuffer+8, 16);

		/* Display data for debug if requested */
		#ifdef MIFAREDEBUG
			printf("Block %d\r\n", blockNumber);
			PN532_PrintHexChar(data, 16);
		#endif

		return 1;

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - PN532_mifareclassic_ReadDataBlock: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - PN532_mifareclassic_ReadDataBlock: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - PN532_mifareclassic_ReadDataBlock: Failed to write command\r\n");
			break;
		}
		#endif
	}

	return 0;

}

/**************************************************************************/
/*!
    Tries to write an entire 16-byte data block at the specified block
    address.

    @param  blockNumber   The block number to authenticate.  (0..63 for
                          1KB cards, and 0..255 for 4KB cards).
    @param  data          The byte array that contains the data to write.

    @returns 1 if everything executed properly, 0 for an error
*/
/**************************************************************************/

bool PN532_mifareclassic_WriteDataBlock (uint8_t blockNumber, uint8_t *data)
{
	#ifdef MIFAREDEBUG
		printf("Trying to write 16 bytes to block %d\r\n", blockNumber);
	#endif

	/* Prepare the command */
	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
	pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;
	pn532_packetbuffer[1] = 1;                      /* Card number */
	pn532_packetbuffer[2] = MIFARE_CMD_WRITE;       /* Mifare Write command = 0xA0 */
	pn532_packetbuffer[3] = blockNumber;            /* Block Number (0..63 for 1K, 0..255 for 4K) */
	memcpy (pn532_packetbuffer+4, data, 16);        /* Data Payload */

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 20, TIMEOUT_1S);

	if (AckResponse == 1) {
		// Wait a short bit
		MCUsleep(10);
		/* Read the response packet */
		memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
		// read data packet to see ok
		readDataPacket(pn532_packetbuffer, 26);

		// That's it....?

		return 1;

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - PN532_mifareclassic_WriteDataBlock: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - PN532_mifareclassic_WriteDataBlock: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - PN532_mifareclassic_WriteDataBlock: Failed to write command\r\n");
			break;
		}
		#endif
	}

	return 0;

}

/**************************************************************************/
/*!
    Tries to authenticate a block of memory on a MIFARE card using the
    INDATAEXCHANGE command.  See section 7.3.8 of the PN532 User Manual
    for more information on sending MIFARE and other commands.

    @param  uid           Pointer to a byte array containing the card UID
    @param  uidLen        The length (in bytes) of the card's UID (Should
                          be 4 for MIFARE Classic)
    @param  blockNumber   The block number to authenticate.  (0..63 for
                          1KB cards, and 0..255 for 4KB cards).
    @param  keyNumber     Which key type to use during authentication
                          (0 = MIFARE_CMD_AUTH_A, 1 = MIFARE_CMD_AUTH_B)
    @param  keyData       Pointer to a byte array containing the 6 byte
                          key value

    @returns 1 if everything executed properly, 0 for an error
*/
/**************************************************************************/

bool PN532_mifareclassic_AuthenticateBlock (uint8_t *uid, uint8_t uidLen, uint32_t blockNumber, uint8_t keyNumber, const uint8_t *keyData)
{
	uint8_t i = 0;
	uint8_t _uid[7];       // ISO14443A uid
	uint8_t _uidLen;       // uid len
	uint8_t _key[6];       // Mifare Classic key

	// Hang on to the key and uid data
	memcpy(_key, keyData, 6);
	memcpy(_uid, uid, uidLen);
	_uidLen = uidLen;

	#ifdef MIFAREDEBUG
		printf("Trying to authenticate card: ");
		PN532_PrintHex(_uid, _uidLen);
		printf("Using authentication KEY %C: ", keyNumber ? "B" : "A");
		PN532_PrintHex(_key, 6);
	#endif

	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));

	/* Prepare the command */
	pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;   /* Data Exchange Header */
	pn532_packetbuffer[1] = 1;                              /* Max card numbers */
	pn532_packetbuffer[2] = (keyNumber) ? MIFARE_CMD_AUTH_B : MIFARE_CMD_AUTH_A;
	pn532_packetbuffer[3] = blockNumber;                    /* Block Number (1K = 0..63, 4K = 0..255 */
	memcpy (pn532_packetbuffer+4, _key, 6);
	for (i = 0; i < _uidLen; i++)
	{
		pn532_packetbuffer[10+i] = _uid[i];                /* 4 byte card ID */
	}

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 10+_uidLen, TIMEOUT_1S);

	if (AckResponse == 1) {

		memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));

		// read data packet
		readDataPacket(pn532_packetbuffer, 12);

		// check if the response is valid and we are authenticated???
		// for an auth success it should be bytes 5-7: 0xD5 0x41 0x00
		// Mifare auth error is technically byte 7: 0x14 but anything other and 0x00 is not good

		if (pn532_packetbuffer[7] != 0x00) {
			#ifdef PN532DEBUG
			printf("Authentification failed: ");
			PN532_PrintHexChar(pn532_packetbuffer, 12);
			#endif

			return 0;

		}

		return 1;

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - PN532_mifareclassic_AuthenticateBlock: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - PN532_mifareclassic_AuthenticateBlock: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - PN532_mifareclassic_AuthenticateBlock: Failed to write command\r\n");
			break;
		}
		#endif
	}

	return 0;

}

/**************************************************************************/
/*!
    Reads the ISO14443A target device ID when it is in the field

    @param  uid           Pointer to the array that will be populated
                          with the card's UID (up to 7 bytes)
    @param  uidLength     Pointer to the variable that will hold the
                          length of the card's UID.

    @returns 1 if everything executed properly, 0 for an error
*/
/**************************************************************************/
bool PN532_readPassiveTargetID(uint8_t * uid, uint8_t * uidLength)
{
	uint16_t sens_res = 0;
	uint8_t i = 0;

	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
	// read data packet
	readDataPacket(pn532_packetbuffer, 20);

	// first check some basic stuff
	/* ISO14443A card response should be in the following format:
	byte            Description
	-------------   ------------------------------------------
	b0..6           Frame header and preamble
	b7              Tags Found
	b8              Tag Number (only one used in this example)
	b9..10          SENS_RES
	b11             SEL_RES
	b12             NFCID Length
	b13..NFCIDLen   NFCID                                      */

	if (pn532_packetbuffer[7] != 1) {
		#ifdef MIFAREDEBUG
		  printf("Found %d tags. Only 1 at a time please.\r\n", pn532_packetbuffer[7]);
		#endif
		  return 0;
	}

	sens_res = pn532_packetbuffer[9];
	sens_res <<= 8;
	sens_res |= pn532_packetbuffer[10];

	#ifdef MIFAREDEBUG
	  printf("ATQA: 0x%04X\r\n", sens_res);
	  printf("SAK: 0x%02X\r\n", pn532_packetbuffer[11]);
	#endif

	/* Card appears to be Mifare Classic */
	*uidLength = pn532_packetbuffer[12];
	#ifdef MIFAREDEBUG
	  printf("UID:");
	#endif
	for (i=0; i < pn532_packetbuffer[12]; i++) {
	  uid[i] = pn532_packetbuffer[13+i];
	  #ifdef MIFAREDEBUG
		printf(" 0x%02X", uid[i]);
	  #endif
	}
	#ifdef MIFAREDEBUG
		printf("\r\n");
	#endif

	return 1;
}

/**************************************************************************/
/*!
    Initiates Controller to detect when an ISO14443A target enters the field

    @param  cardBaudRate  Baud rate of the card

    @returns 1 if everything executed properly, 0 for an error
*/
/**************************************************************************/
bool PN532_initiateCardReader(uint8_t cardbaudrate)
{

	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));

	/* Prepare the command */
	pn532_packetbuffer[0] = PN532_COMMAND_INLISTPASSIVETARGET;
	pn532_packetbuffer[1] = 1;  // max 1 cards at once (we can set this to 2 later)
	pn532_packetbuffer[2] = cardbaudrate;

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 3, TIMEOUT_1S);

	if (AckResponse == 1) {

		// read data packet
		return 1;

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - PN532_initiateCardReader: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - PN532_initiateCardReader: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - PN532_initiateCardReader: Failed to write command\r\n");
			break;
		}
		#endif
	}

	return 0;
}


/**************************************************************************/
/*!
    @brief  Configures the SAM (Secure Access Module)
*/
/**************************************************************************/
bool PN532_SAMConfig(void)
{

	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
	/* Prepare the command */
	pn532_packetbuffer[0] = PN532_COMMAND_SAMCONFIGURATION;
	pn532_packetbuffer[1] = 0x01; // normal mode;
	pn532_packetbuffer[2] = 0x14; // timeout 50ms * 20 = 1 second
	pn532_packetbuffer[3] = 0x01; // use IRQ pin!

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 4, TIMEOUT_1S);

	if (AckResponse == 1) {
		memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
		// read data packet
		readDataPacket(pn532_packetbuffer, 8);

		int offset = 6;
		return  (pn532_packetbuffer[offset] == 0x15);

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - PN532_SAMConfig: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - PN532_SAMConfig: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - PN532_SAMConfig: Failed to write command\r\n");
			break;

		}
		#endif
	}

	return 0;
}


/**************************************************************************/
/*!
    @brief  applies GetFirmware command and retrieves the data.

    @param  N/A
*/
/**************************************************************************/

uint32_t I2C_getPN532FirmwareVersion(void)
{
	uint32_t response;
	// write the Firmware Request command to PM532
	memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
	pn532_packetbuffer[0] = PN532_COMMAND_GETFIRMWAREVERSION;

	/* Send the command */
	AckResponse = sendCommandCheckAck(pn532_packetbuffer, 1, TIMEOUT_1S);

	if (AckResponse == 1) {
		memset(&pn532_packetbuffer, 0, sizeof(pn532_packetbuffer));
		// Can Now read the firmware data
		readDataPacket(pn532_packetbuffer, 12);

		// check some basic stuff first
		if (0 != strncmp((char *)pn532_packetbuffer, (char *)pn532response_firmwarevers, 6)) {
		#ifdef PN532DEBUG
		printf("Sorry, Firmware doesn't match!\r\n");
		#endif
		return 0;
		}

		int offset = 7;  // Skip a response byte when using I2C to ignore extra data.
		response = pn532_packetbuffer[offset++];
		response <<= 8;
		response |= pn532_packetbuffer[offset++];
		response <<= 8;
		response |= pn532_packetbuffer[offset++];
		response <<= 8;
		response |= pn532_packetbuffer[offset++];

		return response;

	}
	else {
		// Error Handling
		#ifdef PN532DEBUG
		switch (AckResponse) {
		case 2:
			printf("ERR - I2C_getPN532FirmwareVersion: Failed to receive Ack Response\r\n");
			break;
		case 3:
			printf("ERR - I2C_getPN532FirmwareVersion: Failed to receive IRQ pin state change within timeout\r\n");
			break;
		case 4:
			printf("ERR - I2C_getPN532FirmwareVersion: Failed to write command\r\n");
			break;

		}
		#endif
	}
	return 0;
}

/**************************************************************************/
/*!
    @brief  resets the PN532 module by toggling VEN pin.

    @param  N/A
*/
/**************************************************************************/


void PN532reset(void)
{
	GPIO_SetPinsOutput(PN532_VEN_GPIO, 1U << PN532_VEN_PIN);
	GPIO_ClearPinsOutput(PN532_VEN_GPIO, 1U << PN532_VEN_PIN);
	MCUsleep(160);
	GPIO_SetPinsOutput(PN532_VEN_GPIO, 1U << PN532_VEN_PIN);
	MCUsleep(90);
}

/**************************************************************************/
/*!
    @brief  Prints a hexadecimal value in plain characters

    @param  data      Pointer to the byte data
    @param  numBytes  Data length in bytes
*/
/**************************************************************************/
void PN532_PrintHex(const uint8_t* data, const uint32_t numBytes)
{
  uint32_t i=0;
  for (i=0; i < numBytes; i++)
  {
    printf(" 0x%02X", data[i]);
  }
  printf("\r\n");
}

/**************************************************************************/
/*!
    @brief  Prints a hexadecimal value in plain characters, along with
            the char equivalents in the following format

            00 00 00 00 00 00  ......

    @param  data      Pointer to the byte data
    @param  numBytes  Data length in bytes
*/
/**************************************************************************/
void PN532_PrintHexChar(const uint8_t* data, const uint32_t numBytes)
{
	uint32_t i=0;
	char c;
	printf("Hex:");
	for (i = 0; i < numBytes; i++) {
		printf(" %02X", data[i]);
	}

	printf(" ->Reads: ");
    for (i = 0; i < numBytes; i++) {
        c = (char)data[i];
        if (c <= 0x1f || c > 0x7f) {
            printf(".");
        } else {
            printf("%c", c);
        }
    }
    printf("\r\n");

}

/**************************************************************************/
/*!
    @brief  Creates a defined (ms) delay
    @param  N/A
*/
/**************************************************************************/
void MCUsleep(uint32_t ms)
{
	int i;
#ifndef DEBUG_SEMIHOSTING
	for(i=0; i<(ms * LOOP_REF); i++) asm("nop");
# else
	if(ms <= CLOCK_CALL_TIME)
	{
		for(i=0; i<(ms * LOOP_REF); i++) asm("nop");
	}
	else
	{
		clock_t time = clock() + ((ms - CLOCK_CALL_TIME)/10);
		while (clock() <= time);
	}
#endif
}


