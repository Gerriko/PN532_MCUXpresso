/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 * Application Copyright 2019 BigG (gerrikoio)
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*  SDK Included Files */
#include <projectML/project2boardmappings.h>
#include <stdio.h>
#include <time.h>

#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_i2c.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_gpio.h"
#include "fsl_port.h"
#include "fsl_common.h"

#include "PN532.h"


/*******************************************************************************
 * Variables
 ******************************************************************************/

i2c_master_config_t masterConfig;
uint32_t sourceClock;
i2c_master_transfer_t masterXfer;

const uint8_t KEYA[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };

uint32_t cardid;							// Used to get the Mifare Classic Card ID

uint8_t ReadSuccess;
uint8_t Prev_uid[] = { 0, 0, 0, 0, 0, 0, 0 };  	// Buffer to store the previous returned UID
uint8_t uid[] = { 0, 0, 0, 0, 0, 0, 0 };  		// Buffer to store the current returned UID
uint8_t uidLength;                        		// Length of the UID (4 or 7 bytes depending on ISO14443A card type)

bool DiffUID = false;							// Only process if it is different UID or if some time has elapsed


/*******************************************************************************
 * Code
 ******************************************************************************/


/*!
 * @brief Main function
 */
int main(void)
{
	uint8_t i = 0;
	uint8_t AuthTestData[16];					// Used to authenticate mifare cards

    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_I2C_ConfigurePins();
    BOARD_InitDebugConsole();

    PRINTF("\r\nPN532 I2C -- Read Mifare/NTAGs\r\n");

    I2C_MasterGetDefaultConfig(&masterConfig);

    masterConfig.baudRate_Bps = I2C_BAUDRATE;

    sourceClock = HOST_I2C_CLK_FREQ;

    I2C_MasterInit(HOST_I2C_MASTER_BASEADDR, &masterConfig, sourceClock);

    memset(&masterXfer, 0, sizeof(masterXfer));

    masterXfer.slaveAddress = PN532_SLAVE_ADDRESS;
    masterXfer.subaddress = 0;
    masterXfer.subaddressSize = 0;

    // Reset the PN532 Module
    PN532reset();

	// Now check if we can get the Firmware Version
    uint32_t versiondata = I2C_getPN532FirmwareVersion();
    if (! versiondata) {
    	PRINTF("Didn't find PN53x board\r\n");
    	return 0; // halt
    }

    // Got ok data, print it out!
    printf("Found chip PN5%X ", (versiondata>>24) & 0xFF);
    printf("Firmware ver. %d",(versiondata>>16) & 0xFF);
    printf(".");
    printf("%d\r\n",(versiondata>>8) & 0xFF);

    // configure board to read RFID tags
    if (!PN532_SAMConfig()) {
    	PRINTF("SAM Config failed");
    	return 0; // halt
    }

    while (1)
    {
    	printf("\r\nOK! READY...\r\n");

    	// Initiate PN532 as a ISO14443A type (Mifare, etc.) card reader
    	if (PN532_initiateCardReader(PN532_MIFARE_ISO14443A)) {
    		// Now wait indefinitely for an IRQ pin trigger.  When pin is triggered
    		// 'uid' will be populated with the UID, and uidLength will indicate
    		// if the uid is 4 bytes (Mifare Classic) or 7 bytes (Mifare Ultralight)

    		// ----------------------------------------------------------------
    		// We can set up an interrupt or we can poll as doing here...
    		// ================================================================

    		while (GPIO_ReadPinInput(PN532_IRQ_GPIO, PN532_IRQ_PIN) == 1) {;;}

    		printf("\r\nCARD DETECTED\r\n");

    		memset(&uid, 0, sizeof(uid));
    		memset(&AuthTestData, 0, sizeof(AuthTestData));

    		if (PN532_readPassiveTargetID(uid, &uidLength)) {

				printf("\r\nISO14443A CARD READ FEEDBACK:\r\n");
				// Display some basic information about the card
				printf("  UID Length: %d bytes\r\n", uidLength);
				printf("  UID Value:");
				PN532_PrintHex(uid, uidLength);
				printf("\r\n");

				switch (uidLength) {

				// This handles the Mifare Classic card ...
				case 4:
					printf("A Mifare Classic card (4 byte UID)\r\n");
					cardid = uid[0];
					cardid <<= 8;
					cardid |= uid[1];
					cardid <<= 8;
					cardid |= uid[2];
					cardid <<= 8;
					cardid |= uid[3];
					printf("  with card ID # %ld\r\n", cardid);

					// Now we need to try to authenticate it for read/write access
					// Try with the factory default KeyA: 0xFF 0xFF 0xFF 0xFF 0xFF 0xFF
					printf("\r\nLet's Authenticate block 4 with default KEYA value...\r\n");

					if (PN532_mifareclassic_AuthenticateBlock(uid, uidLength, 4, 0, KEYA)) {
						printf("Sector 1 (Blocks 4..7) AUTHENTICATED!\r\n");

						#ifdef ALLOWWRITETESTS
						// Lets create some test data which we will write to card and then this text should be read back
						memcpy(AuthTestData, (const uint8_t[]){ 'e', 'l', 'e', 'm', 'e', 'n', 't', '1', '4', '.', 'c', 'o', 'm', 0, 0, 0 }, 16);
						if (PN532_mifareclassic_WriteDataBlock (4, AuthTestData)) {
							printf(" ... Write Test Data to Block Successful!\r\n");
						}
						else printf(" ... Write Test Data to Block Failed.\r\n");
						#endif
						// Try to read the contents of block 4
						if (PN532_mifareclassic_ReadDataBlock(4, AuthTestData)) {
							// Data seems to have been read ... spit it out
							printf("\r\nBlock 4 contents:\r\n");
							PN532_PrintHexChar(AuthTestData, 16);
							printf("\r\n");
						}

					}
					else printf(" ... authentication failed! Try another?\r\n");

					break;

				case 7:
					// We probably have an NTAG2xx card (though it could be Ultralight as well)
					printf("A 7 byte UID (Mifare Ultralight or NTAG2xx)\r\n");

					// NTAG2x3 cards have 39*4 bytes of user pages (156 user bytes),
					// starting at page 4 ... larger cards just add pages to the end of
					// this range:

					// See: http://www.nxp.com/documents/short_data_sheet/NTAG203_SDS.pdf

					// TAG Type       PAGES   USER START    USER STOP
					// --------       -----   ----------    ---------
					// NTAG 203       42      4             39
					// NTAG 213       45      4             39
					// NTAG 215       135     4             129
					// NTAG 216       231     4             225
					for (i = 0; i < 42; i++) {
						// Display the current page number
						printf("PAGE %02d:", i);
						// Display the results, depending on 'success'
						if (PN532_ntag2xx_ReadPage(i, AuthTestData)) {
							// Dump the page data
							PN532_PrintHexChar(AuthTestData, 4);
						}
						else {
							printf("Unable to read the requested page!\r\n");
						}
					}

					// Let's check if Mifare ultralight
					// Try to read the first general-purpose user page (#4)
					printf("Reading page 4\r\n");
					if (PN532_mifareultralight_ReadPage (4, AuthTestData)) {
						// Data seems to have been read ... spit it out
						PN532_PrintHexChar(AuthTestData, 4);
						printf("\r\n");
					}

					break;

				default:
					printf("Unknown Card Type!\r\n");

				}

				// Now wait until card is removed from the reader - elaborate method to
				while(1) {
					// Copy this UID across to Prev_uid
					memcpy (Prev_uid, uid, uidLength);
					DiffUID = false;
			    	// Initiate PN532 as a ISO14443A type (Mifare, etc.) card reader
			    	if (PN532_initiateCardReader(PN532_MIFARE_ISO14443A)) {
			    		cardid = 1;
			    		while (GPIO_ReadPinInput(PN532_IRQ_GPIO, PN532_IRQ_PIN) == 1) {
			    			cardid++;
			    			if (cardid > 100000) {		// Timeout
			    				cardid = 0;
			    				break;
			    			}
			    		}
			    		if (cardid) {
							if (PN532_readPassiveTargetID(uid, &uidLength)) {
								for (i = 0; i < uidLength; i++) {
									if (uid[i] != Prev_uid[i]) {
										DiffUID = true;
										break;
									}
								}
								if (DiffUID) break;
							}
			    			else break;
			    		}
						else break;
			    	}
				}
				printf("CARD REMOVED.\r\n");
    		}
    	}
    }
}
